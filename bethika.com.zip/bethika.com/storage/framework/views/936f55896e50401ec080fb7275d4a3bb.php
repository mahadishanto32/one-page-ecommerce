
<?php $__env->startSection('title', 'Product Categories'); ?>
<?php $__env->startSection('page-title', 'Product Categories'); ?>

<?php $__env->startSection('content'); ?>
<div class="admin-card">
    <div class="admin-card-header">
        <h3><i class="fa-solid fa-layer-group"></i> Product Categories</h3>
        <a href="<?php echo e(route('admin.product-categories.create')); ?>" class="btn-admin btn-admin-primary">
            <i class="fa-solid fa-plus"></i> Add New Category
        </a>
    </div>

    <div class="admin-card-body">

        <?php if(session('success')): ?>
            <div class="admin-alert admin-alert-success" data-auto-dismiss>
                <i class="fa-solid fa-circle-check"></i>
                <span><?php echo e(session('success')); ?></span>
                <button type="button" class="btn-close" onclick="this.closest('.admin-alert').remove()">&times;</button>
            </div>
        <?php endif; ?>

        <!-- Filter Bar -->
        <div class="filters-bar" style="padding:0 0 18px; border-bottom:none;">
            <div class="filter-field">
                <label for="categorySearch">Search</label>
                <div class="input-group-icon">
                    <i class="fa-solid fa-magnifying-glass input-icon"></i>
                    <input type="text" id="categorySearch" class="form-control" placeholder="Search by category name...">
                </div>
            </div>
            <div class="filter-field filter-select-field">
                <label for="categoryStatusFilter">Status</label>
                <select id="categoryStatusFilter" class="form-select">
                    <option value="">All Statuses</option>
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                </select>
            </div>
        </div>

        <div class="table-responsive">
            <table id="categoriesTable" class="table-admin" style="width:100%">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Serial</th>
                        <th>Status</th>
                        <th class="text-right">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <?php if($category->image): ?>
                                    <img src="<?php echo e(asset('uploads/product-categories/' . $category->image)); ?>"
                                         alt="<?php echo e($category->name); ?>" class="product-thumb">
                                <?php else: ?>
                                    <div class="product-thumb d-flex align-items-center justify-content-center">
                                        <i class="fa-solid fa-image text-muted"></i>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td class="product-name"><?php echo e($category->name); ?></td>
                            <td><?php echo e($category->serial); ?></td>
                            <td>
                                <?php if($category->status): ?>
                                    <span class="status-pill completed">Active</span>
                                <?php else: ?>
                                    <span class="status-pill cancelled">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-right">
                                <a href="<?php echo e(route('admin.product-categories.edit', $category->id)); ?>"
                                   class="btn-icon-admin" title="Edit">
                                    <i class="fa-solid fa-pen"></i>
                                </a>
                                <form action="<?php echo e(route('admin.product-categories.destroy', $category->id)); ?>"
                                      method="POST" class="d-inline-block"
                                      onsubmit="return confirm('Are you sure you want to delete this category?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn-icon-admin danger" title="Delete">
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted py-4">
                                No product categories found.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function () {
    // Initialize DataTable — client-side search, sort & pagination.
    var table = $('#categoriesTable').DataTable({
        responsive: true,
        pageLength: 10,
        lengthChange: false,
        // Actions column shouldn't be sortable
        columnDefs: [
            { orderable: false, targets: -1 },
            { orderable: false, targets: 1 }
        ],
        language: {
            emptyTable: "No product categories found.",
            zeroRecords: "No matching categories found."
        }
    });

    // Custom search box (Name)
    $('#categorySearch').on('keyup', function () {
        table.search(this.value).draw();
    });

    // Custom status filter (matches the "Active" / "Inactive" text in the Status column)
    $('#categoryStatusFilter').on('change', function () {
        var val = this.value;
        table.column(4).search(val ? '^' + val + '$' : '', true, false).draw();
    });

    // Auto-dismiss success alert
    setTimeout(function () {
        $('[data-auto-dismiss]').fadeOut();
    }, 4000);
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\bethika.com\resources\views/admin/product-categories/index.blade.php ENDPATH**/ ?>