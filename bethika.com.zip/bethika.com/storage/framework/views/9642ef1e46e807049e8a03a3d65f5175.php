
<?php $__env->startSection('title', 'Attribute Options'); ?>
<?php $__env->startSection('page-title', 'Attribute Options'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <div class="row">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                    <h5 class="mb-0 fw-bold text-primary">
                        <i class="fas fa-list-ul me-2"></i> Attribute Options
                    </h5>
                    <a href="<?php echo e(route('admin.attribute-options.create')); ?>" class="btn btn-primary btn-sm">
                        <i class="fas fa-plus me-1"></i> Add New Option
                    </a>
                </div>

                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show m-3" role="alert">
                        <i class="fas fa-check-circle me-2"></i> <?php echo e(session('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show m-3" role="alert">
                        <i class="fas fa-exclamation-circle me-2"></i> <?php echo e(session('error')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <div class="card-body">
                    <div class="table-responsive">
                        <table id="optionsTable" class="table table-hover table-striped w-100">
                            <thead class="table-light">
                                <tr>
                                    <th class="text-center">#</th>
                                    <th>Name</th>
                                    <th>Attribute</th>
                                    <th>Status</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="text-center fw-bold"><?php echo e($loop->iteration); ?></td>
                                        <td class="fw-semibold"><?php echo e($option->name); ?></td>
                                        <td>
                                            <span class="badge bg-info text-white bg-opacity-10 px-3 py-2 rounded-pill">
                                                <i class="fas fa-tag me-1"></i> <?php echo e($option->attribute->name ?? 'N/A'); ?>

                                            </span>
                                        </td>

                                        <td>
                                            <?php if($option->status): ?>
                                                <span class="badge bg-success bg-opacity-10 text-success px-3 py-2 rounded-pill">
                                                    <i class="fas fa-check-circle me-1"></i> Active
                                                </span>
                                            <?php else: ?>
                                                <span class="badge bg-danger bg-opacity-10 text-danger px-3 py-2 rounded-pill">
                                                    <i class="fas fa-times-circle me-1"></i> Inactive
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <div class="btn-group" role="group">
                                                <a href="<?php echo e(route('admin.attribute-options.edit', $option->id)); ?>"
                                                   class="btn btn-outline-primary btn-sm rounded-pill me-1 px-3"
                                                   title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <form action="<?php echo e(route('admin.attribute-options.destroy', $option->id)); ?>"
                                                      method="POST" class="d-inline-block"
                                                      onsubmit="return confirm('Are you sure you want to delete this option?');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit"
                                                            class="btn btn-outline-danger btn-sm rounded-pill px-3"
                                                            title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="text-center py-5">
                                            <div class="text-muted">
                                                <i class="fas fa-list-ul fa-3x mb-3 d-block"></i>
                                                <p class="mb-0">No attribute options found.</p>
                                                <a href="<?php echo e(route('admin.attribute-options.create')); ?>" class="btn btn-primary btn-sm mt-3">
                                                    <i class="fas fa-plus me-1"></i> Create First Option
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#optionsTable').DataTable({
            responsive: true,
            language: {
                search: "_INPUT_",
                searchPlaceholder: "Search options...",
                lengthMenu: "Show _MENU_ entries",
                info: "Showing _START_ to _END_ of _TOTAL_ options",
                infoEmpty: "No options found",
                infoFiltered: "(filtered from _MAX_ total options)",
                zeroRecords: "No matching options found"
            },
            columnDefs: [
                { orderable: false, targets: [0, 4] },
                { width: "60px", targets: [1] },
                { width: "100px", targets: [4] }
            ],
            order: [[2, 'asc']],
            pageLength: 10,
            lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]]
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\bethika.com\resources\views/admin/attribute-options/index.blade.php ENDPATH**/ ?>