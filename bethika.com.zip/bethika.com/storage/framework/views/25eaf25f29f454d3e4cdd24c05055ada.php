
<?php $__env->startSection('title', 'Product'); ?>
<?php $__env->startSection('page-title', 'Product'); ?>
<?php $__env->startSection('content'); ?>



<?php if(session('success')): ?>
    <div class="admin-alert admin-alert-success" data-auto-dismiss>
        <i class="fa-solid fa-circle-check"></i>
        <span><?php echo e(session('success')); ?></span>
        <button type="button" class="btn-close" onclick="this.closest('.admin-alert').remove()">&times;</button>
    </div>
<?php endif; ?>

<div class="admin-card">
    <div class="admin-card-header">
        <h3><i class="fa-solid fa-box"></i> Products</h3>
        <a href="<?php echo e(route('admin.products.create')); ?>" class="btn-admin btn-admin-primary">
            <i class="fa-solid fa-plus"></i> Add New Product
        </a>
    </div>

    <div class="filters-bar">
        <div class="filter-field" style="flex:1;">
            <label for="product-search">Search</label>
            <input type="text" id="product-search" class="form-control" placeholder="Search by name or SKU...">
        </div>

        <div class="filter-field filter-select-field">
            <label for="category-filter">Category</label>
            <select id="category-filter" class="form-select">
                <option value="">All Categories</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->name); ?>"><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="filter-field" style="align-self:flex-end;">
            <button type="button" id="reset-filters" class="btn-admin btn-admin-outline">
                <i class="fa-solid fa-rotate-left"></i> Reset
            </button>
        </div>
    </div>

    <div class="admin-card-body">
        <div class="table-responsive">
            <table id="products-table" class="table-admin" style="width:100%;">
                <thead>
                    <tr>
                        <th style="width: 50px;">SL</th>
                        <th style="width: 70px;">Image</th>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Stock</th>
                        <th>Status</th>
                        <th style="width: 120px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>

                            <td>
                                <img src="<?php echo e(asset('uploads/products/' . $product->featured_image)); ?>"
                                    alt="<?php echo e($product->name); ?>"
                                    class="product-thumb">
                            </td>

                            <td>
                                <div class="product-name"><?php echo e($product->name); ?></div>

                                <?php if($product->sku): ?>
                                    <div class="product-sku">SKU: <?php echo e($product->sku); ?></div>
                                <?php endif; ?>
                            </td>

                            <td>
                                <?php echo e($product->category->name ?? '-'); ?>

                            </td>

                            <td>
                                <span class="price-current">
                                    <?php echo e(number_format($product->price, 2)); ?>

                                </span>

                                <?php if($product->previous_price): ?>
                                    <br>
                                    <span class="price-previous">
                                        <?php echo e(number_format($product->previous_price, 2)); ?>

                                    </span>
                                <?php endif; ?>
                            </td>

                            <td>
                                <?php
                                    $stockClass = match ($product->stock_status) {
                                        'In Stock' => 'completed',
                                        'Out of Stock' => 'cancelled',
                                        'Pre-Order' => 'pending',
                                        default => 'processing',
                                    };
                                ?>

                                <span class="status-pill <?php echo e($stockClass); ?>">
                                    <?php echo e($product->stock_status); ?>

                                </span>
                            </td>

                            <td>
                                <span class="status-pill <?php echo e($product->status === 'Active' ? 'completed' : 'cancelled'); ?>">
                                    <?php echo e($product->status); ?>

                                </span>
                            </td>

                            <td>
                                <a href="<?php echo e(route('admin.products.edit', $product->id)); ?>"
                                class="btn-icon-admin"
                                title="Edit">
                                    <i class="fa-solid fa-pen"></i>
                                </a>

                                <form action="<?php echo e(route('admin.products.destroy', $product->id)); ?>"
                                    method="POST"
                                    class="d-inline"
                                    onsubmit="return confirm('Are you sure you want to delete this product?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button type="submit"
                                            class="btn-icon-admin danger"
                                            title="Delete">
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function () {
    var table = $('#products-table').DataTable({
        responsive: true,
        pageLength: 10,

        order: [[0, 'asc']],

        language: {
            emptyTable: 'No products found.',
            zeroRecords: 'No products match your search.'
        },

        columnDefs: [
            { orderable: false, targets: [1, 7] }
        ]
    });

    $('#product-search').on('keyup', function () {
        table.search(this.value).draw();
    });

    $('#category-filter').on('change', function () {
        var value = this.value;

        table
            .column(3)
            .search(
                value
                    ? '^' + $.fn.dataTable.util.escapeRegex(value) + '$'
                    : '',
                true,
                false
            )
            .draw();
    });

    $('#reset-filters').on('click', function () {
        $('#product-search').val('');
        $('#category-filter').val('');

        table.search('');
        table.column(3).search('');
        table.draw();
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\bethika.com\resources\views/admin/products/index.blade.php ENDPATH**/ ?>