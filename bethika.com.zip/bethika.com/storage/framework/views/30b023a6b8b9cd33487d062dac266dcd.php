<div class="sidebar">
    <div class="sidebar-brand">
        <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="Admin Logo">
        <h3>Admin Panel</h3>
    </div>

    <ul class="sidebar-menu">

        <li>
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
                <span class="icon"><i class="fa-solid fa-chart-line"></i></span> Dashboard
            </a>
        </li>

        <li>
            <a href="<?php echo e(route('admin.orders.index')); ?>" class="<?php echo e(request()->routeIs('admin.orders*') ? 'active' : ''); ?>">
                <span class="icon"><i class="fa-solid fa-chart-line"></i></span> Orders
            </a>
        </li>

        
        <li class="has-submenu <?php echo e(request()->routeIs('admin.products*') || request()->routeIs('admin.product-categories*') || request()->routeIs('admin.product-subcategories*') || request()->routeIs('admin.brands*') || request()->routeIs('admin.attributes*') || request()->routeIs('admin.attribute-options*') ? 'open' : ''); ?>">
            <a href="#" class="dropdown-toggle <?php echo e(request()->routeIs('admin.products*') || request()->routeIs('admin.product-categories*') || request()->routeIs('admin.product-subcategories*') || request()->routeIs('admin.brands*') || request()->routeIs('admin.attributes*') || request()->routeIs('admin.attribute-options*') ? 'active' : ''); ?>">
                <span class="icon"><i class="fa-solid fa-boxes-stacked"></i></span> Products
                <i class="fa-solid fa-chevron-down submenu-arrow"></i>
            </a>
            <ul class="submenu">
                <li>
                    <a href="<?php echo e(route('admin.products.index')); ?>" class="<?php echo e(request()->routeIs('admin.products*') ? 'active' : ''); ?>">
                        <span class="icon"><i class="fa-solid fa-bag-shopping"></i></span> Products
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.product-categories.index')); ?>" class="<?php echo e(request()->routeIs('admin.product-categories*') ? 'active' : ''); ?>">
                        <span class="icon"><i class="fa-solid fa-sitemap"></i></span> Product Categories
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.attributes.index')); ?>" class="<?php echo e(request()->routeIs('admin.attributes*') ? 'active' : ''); ?>">
                        <span class="icon"><i class="fa-solid fa-sliders"></i></span> Product Attributes
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('admin.attribute-options.index')); ?>" class="<?php echo e(request()->routeIs('admin.attribute-options*') ? 'active' : ''); ?>">
                        <span class="icon"><i class="fa-solid fa-list-check"></i></span> Attribute Options
                    </a>
                </li>
            </ul>
        </li>

        <li>
            <a href="<?php echo e(route('admin.homesliders.index')); ?>" class="<?php echo e(request()->routeIs('admin.homesliders*') ? 'active' : ''); ?>">
                <span class="icon"><i class="fa-solid fa-images"></i></span> Home Sliders
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.reviews.index')); ?>" class="<?php echo e(request()->routeIs('admin.reviews*') ? 'active' : ''); ?>">
                <span class="icon"><i class="fa-solid fa-star"></i></span> Reviews
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.settings.index')); ?>" class="<?php echo e(request()->routeIs('admin.settings*') ? 'active' : ''); ?>">
                <span class="icon"><i class="fa-solid fa-cog"></i></span> Settings
            </a>
        </li>
    </ul>
</div><?php /**PATH C:\xampp\htdocs\bethika.com\resources\views/admin/partials/sidebar.blade.php ENDPATH**/ ?>