
<?php $__env->startSection('title', 'Edit Product Category'); ?>
<?php $__env->startSection('page-title', 'Edit Product Category'); ?>

<?php $__env->startSection('content'); ?>
<div class="admin-card">
    <div class="admin-card-header">
        <h3><i class="fa-solid fa-pen"></i> Edit Product Category</h3>
        <a href="<?php echo e(route('admin.product-categories.index')); ?>" class="btn-admin btn-admin-outline">
            <i class="fa-solid fa-arrow-left"></i> Back to List
        </a>
    </div>

    <div class="admin-card-body">

        <?php if($errors->any()): ?>
            <div class="admin-alert admin-alert-danger">
                <i class="fa-solid fa-circle-exclamation"></i>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('admin.product-categories.update', $category->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="product-form-section">
                <div class="product-form-section-header">
                    <div class="section-icon"><i class="fa-solid fa-circle-info"></i></div>
                    <div>
                        <h5>Category Details</h5>
                        <div class="section-subtitle">Basic information about the product category.</div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-8 mb-3">
                        <label for="name" class="form-label">Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" id="name" value="<?php echo e(old('name', $category->name)); ?>"
                               class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               placeholder="Enter category name" required>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-md-4 mb-3">
                        <label for="serial" class="form-label">Serial</label>
                        <input type="number" name="serial" id="serial" value="<?php echo e(old('serial', $category->serial)); ?>"
                               class="form-control <?php $__errorArgs = ['serial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               placeholder="Display order">
                        <?php $__errorArgs = ['serial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <div class="product-form-section media-upload-box">
                <div class="product-form-section-header">
                    <div class="section-icon"><i class="fa-solid fa-image"></i></div>
                    <div>
                        <h5>Logo / Image</h5>
                        <div class="section-subtitle">Leave empty to keep the current image. Max size 5MB.</div>
                    </div>
                </div>

                <?php if($category->image): ?>
                    <div class="media-current-preview">
                        <img src="<?php echo e(asset('uploads/product-categories/' . $category->image)); ?>" alt="<?php echo e($category->name); ?>">
                        <div>
                            <div class="fw-bold" style="font-size:13px; color:#111827;">Current image</div>
                            <div class="form-text" style="margin-top:0;">Choose a new file below to replace it.</div>
                        </div>
                    </div>
                <?php endif; ?>

                <input type="file" name="image" id="image" accept="image/*"
                       class="form-control mt-3 <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="product-form-section">
                <div class="product-form-section-header">
                    <div class="section-icon"><i class="fa-solid fa-toggle-on"></i></div>
                    <div>
                        <h5>Visibility</h5>
                        <div class="section-subtitle">Control whether this category is active on the storefront.</div>
                    </div>
                </div>

                <label class="toggle-card" style="max-width:280px;">
                    <input type="checkbox" name="status" id="status" value="1"
                           class="form-check-input" <?php echo e(old('status', $category->status) ? 'checked' : ''); ?>>
                    <span>
                        <span class="toggle-card-title">Active</span>
                        <span class="toggle-card-subtitle">Visible to customers</span>
                    </span>
                </label>
            </div>

            <div class="d-flex gap-2 mt-3">
                <button type="submit" class="btn-admin btn-admin-primary">
                    <i class="fa-solid fa-floppy-disk"></i> Update Category
                </button>
                <a href="<?php echo e(route('admin.product-categories.index')); ?>" class="btn-admin btn-admin-outline">
                    Cancel
                </a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\bethika.com\resources\views/admin/product-categories/edit.blade.php ENDPATH**/ ?>