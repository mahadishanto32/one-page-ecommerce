
<?php $__env->startSection('title', 'Reviews'); ?>
<?php $__env->startSection('page-title', 'Reviews'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <div class="row">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                    <h5 class="mb-0 fw-bold text-primary">
                        <i class="fas fa-star me-2"></i> Reviews
                    </h5>
                    <a href="<?php echo e(route('admin.reviews.create')); ?>" class="btn btn-danger btn-sm">
                        <i class="fas fa-plus me-1"></i> Add New Review
                    </a>
                </div>

                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show m-3" role="alert">
                        <i class="fas fa-check-circle me-2"></i> <?php echo e(session('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show m-3" role="alert">
                        <i class="fas fa-exclamation-circle me-2"></i> <?php echo e(session('error')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <div class="card-body">
                    <div class="table-responsive">
                        <table id="reviewsTable" class="table table-hover table-striped w-100">
                            <thead class="table-light">
                                <tr>
                                    <th class="text-center">Photo</th>
                                    <th>Name</th>
                                    <th>Location / Designation</th>
                                    <th>Message</th>
                                    <th class="text-center">Rating</th>
                                    <th class="text-center">Status</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="text-center">
                                            <?php if($review->photo): ?>
                                                <img src="<?php echo e(asset('uploads/reviews/' . $review->photo)); ?>"
                                                     alt="<?php echo e($review->name); ?>"
                                                     class="review-avatar rounded-circle border"
                                                     width="50" height="50"
                                                     style="object-fit: cover;">
                                            <?php else: ?>
                                                <div class="review-avatar-placeholder rounded-circle d-inline-flex align-items-center justify-content-center bg-light border"
                                                     style="width: 50px; height: 50px;">
                                                    <i class="fas fa-user text-muted"></i>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td class="fw-semibold"><?php echo e($review->name); ?></td>
                                        <td><?php echo e($review->designation ?? '—'); ?></td>
                                        <td>
                                            <span class="review-message-preview" title="<?php echo e($review->message); ?>">
                                                <?php echo e(Str::limit($review->message, 80)); ?>

                                            </span>
                                        </td>
                                        <td class="text-center">
                                            <div class="review-stars">
                                                <?php for($i = 1; $i <= 5; $i++): ?>
                                                    <i class="fas fa-star <?php echo e($i <= $review->rating_point ? 'text-warning' : 'text-muted'); ?>"
                                                       style="font-size: 14px;"></i>
                                                <?php endfor; ?>
                                                <span class="rating-number ms-1 text-muted small">(<?php echo e($review->rating_point); ?>)</span>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <?php if($review->active): ?>
                                                <span class="badge bg-success bg-opacity-10 text-success px-3 py-2 rounded-pill">
                                                    <i class="fas fa-check-circle me-1"></i> Active
                                                </span>
                                            <?php else: ?>
                                                <span class="badge bg-danger bg-opacity-10 text-danger px-3 py-2 rounded-pill">
                                                    <i class="fas fa-times-circle me-1"></i> Inactive
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <div class="btn-group" role="group">
                                                <a href="<?php echo e(route('admin.reviews.edit', $review->id)); ?>"
                                                   class="btn btn-outline-primary btn-sm rounded-pill me-1 px-3"
                                                   title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <form action="<?php echo e(route('admin.reviews.destroy', $review->id)); ?>"
                                                      method="POST" class="d-inline-block"
                                                      onsubmit="return confirm('Are you sure you want to delete this review?');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit"
                                                            class="btn btn-outline-danger btn-sm rounded-pill px-3"
                                                            title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center py-5">
                                            <div class="text-muted">
                                                <i class="fas fa-comment-slash fa-3x mb-3 d-block"></i>
                                                <p class="mb-0">No reviews found.</p>
                                                <a href="<?php echo e(route('admin.reviews.create')); ?>" class="btn btn-primary btn-sm mt-3">
                                                    <i class="fas fa-plus me-1"></i> Create First Review
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#reviewsTable').DataTable({
            responsive: true,
            language: {
                search: "_INPUT_",
                searchPlaceholder: "Search reviews...",
                lengthMenu: "Show _MENU_ entries",
                info: "Showing _START_ to _END_ of _TOTAL_ reviews",
                infoEmpty: "No reviews found",
                infoFiltered: "(filtered from _MAX_ total reviews)",
                zeroRecords: "No matching reviews found"
            },
            columnDefs: [
                { orderable: false, targets: [0, 3, 6] },
                { width: "70px", targets: [0] },
                { width: "120px", targets: [4] },
                { width: "100px", targets: [5] }
            ],
            order: [[1, 'asc']],
            pageLength: 25,
            lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]]
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\bethika.com\resources\views/admin/reviews/index.blade.php ENDPATH**/ ?>