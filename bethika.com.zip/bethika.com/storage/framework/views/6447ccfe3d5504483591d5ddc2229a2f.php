<div class="header">
    <h1><?php echo $__env->yieldContent('page-title', 'Dashboard'); ?></h1>
    <div class="user-info">
        <span>Welcome, <?php echo e(Auth::user()->name); ?></span>
        <span class="badge badge-<?php echo e(Auth::user()->role); ?>">
            <?php echo e(ucfirst(Auth::user()->role)); ?>

        </span>
        <div class="avatar"><?php echo e(strtoupper(substr(Auth::user()->name, 0, 1))); ?></div>
        <form action="<?php echo e(route('admin.logout')); ?>" method="POST" style="display: inline;">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn-logout">
                <i class="fa-solid fa-right-from-bracket"></i> Logout
            </button>
        </form>
    </div>
</div><?php /**PATH C:\xampp\htdocs\bethika.com\resources\views/admin/partials/header.blade.php ENDPATH**/ ?>