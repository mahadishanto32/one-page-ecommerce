
<?php $__env->startSection('title', 'Product'); ?>
<?php $__env->startSection('page-title', 'Product'); ?>
<?php $__env->startSection('content'); ?>

<div class="admin-card">
    <div class="admin-card-header">
        <h3><i class="fa-solid fa-pen-to-square"></i> Edit Product</h3>
        <a href="<?php echo e(route('admin.products.index')); ?>" class="btn-admin btn-admin-outline">
            <i class="fa-solid fa-arrow-left"></i> Back to List
        </a>
    </div>

    <div class="admin-card-body">
        <?php if($errors->any()): ?>
            <div class="admin-alert admin-alert-danger">
                <i class="fa-solid fa-circle-exclamation"></i>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('admin.products.update', $product->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <?php echo $__env->make('admin.products.form', ['product' => $product], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <div class="mt-4 d-flex gap-2">
                <button type="submit" class="btn-admin btn-admin-primary">
                    <i class="fa-solid fa-check"></i> Update Product
                </button>
                <a href="<?php echo e(route('admin.products.index')); ?>" class="btn-admin btn-admin-outline">Cancel</a>
            </div>
        </form>
    </div>
</div>

<?php echo $__env->make('admin.products.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const attributeSelect = document.getElementById('product_attribute_id');
    const optionSelect = document.getElementById('product_attribute_option_id');

    if (attributeSelect && optionSelect) {
        attributeSelect.addEventListener('change', function() {
            const attributeId = this.value;

            // Clear current options
            optionSelect.innerHTML = '<option value="">-- Select Attribute Option --</option>';

            if (attributeId) {
                // Fetch options via AJAX
                fetch(`/admin/get-attribute-options?attribute_id=${attributeId}`)
                    .then(response => response.json())
                    .then(data => {
                        data.forEach(option => {
                            const opt = document.createElement('option');
                            opt.value = option.id;
                            let text = option.name;
                            if (option.added_price) {
                                text += ` (+$${parseFloat(option.added_price).toFixed(2)})`;
                            }
                            opt.textContent = text;
                            optionSelect.appendChild(opt);
                        });
                    })
                    .catch(error => console.error('Error fetching options:', error));
            }
        });
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\bethika.com\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>